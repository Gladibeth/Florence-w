<?php get_header();?>
  <?php get_template_part('partials/index/banner'); ?>
  <?php get_template_part('partials/index/icons'); ?>
  <?php get_template_part('partials/index/about'); ?>
  <?php get_template_part('partials/index/gallery'); ?>
  <?php get_template_part('partials/index/post'); ?>
  <?php get_template_part('partials/index/contact'); ?>
  <?php get_footer();?>
